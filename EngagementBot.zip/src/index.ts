import EngagementBot from './bot';

// Create and start the bot
const bot = new EngagementBot();
bot.start();
